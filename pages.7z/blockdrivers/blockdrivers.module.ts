import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BlockdriversPage } from './blockdrivers';

@NgModule({
  declarations: [
    BlockdriversPage,
  ],
  imports: [
    IonicPageModule.forChild(BlockdriversPage),
  ],
})
export class BlockdriversPageModule {}
