import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { BlockdriversPage } from '../blockdrivers/blockdrivers';
import { AccountPage } from '../account/account';
import { TermPage } from '../term/term';
import { EditprofilePage } from '../editprofile/editprofile';

/**
 * Generated class for the SettingsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-settings',
  templateUrl: 'settings.html',
})
export class SettingsPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SettingsPage');
  }

  blockdriver()
  {
    this.navCtrl.push(BlockdriversPage);
  }
  gotoaccount()
  {
    this.navCtrl.push(AccountPage);
  }
  gototerm()
  {
    this.navCtrl.push(TermPage);
  }
  editprofile()
  {
    this.navCtrl.push(EditprofilePage);
  }
}
